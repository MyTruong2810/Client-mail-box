import tkinter as tk
from tkinter import ttk
from tkinter import filedialog
import sys
import socket
import time
import xml.etree.ElementTree as ET
import os
import base64
import mimetypes
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import subprocess

mails = []


def load_config(file_path):

    tree = ET.parse(file_path)
    root = tree.getroot()

    host = root.find('./server/host').text
    port1 = int(root.find('./server/port1').text)
    port2 = int(root.find('./server/port2').text)
    username = root.find('./authentication/username').text
    password = root.find('./authentication/password').text
    seen_mails_file = root.find('./seen_mails_file').text
    autoload_interval = int(root.find('./autoload_interval').text)

    return host, port1, port2, username, password, seen_mails_file, autoload_interval


# Load configuration from XML
HOST, PORT1, PORT2, username, password, SEEN_EMAILS_FILE, AUTOLOAD_INTERVAL = load_config('config.xml')


class Email:
    def __init__(self):
        self.From = ""
        self.To = ""
        self.To_CC = ""
        self.To_BCC = ""
        self.Subject = ""
        self.AtName = ""
        self.attachments = []
        self.Content = []
        self.extracted_content = []
        self.num = 0
        self.state = 1


def connect_to_server(port):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_address = (HOST, port)
    try:
        client_socket.connect(server_address)
        return client_socket
    except socket.error as e:
        print(f"Error connecting to server: {e}")
        client_socket.close()
        return None


def receive_response(client_socket):
    try:
        data = client_socket.recv(1024)
        return data.decode()
    except socket.error as e:
        print(f"Error receiving response from the server: {e}")
        return None


def _getline(client_socket):
    line = ""
    while True:
        try:
            data = client_socket.recv(1).decode()
            if not data or data == '\n':
                break
            if data != '\r':
                line += data
        except socket.error as e:
            print(f"Error receiving data: {e}")
            break
    return line


def receive_emails(client_socket, mail):
    client_socket.sendall(b"USER " + username.encode('utf-8') + b"\r\n")
    receive_response(client_socket)
    client_socket.sendall(b"STAT\r\n")
    receive_response(client_socket)
    data = client_socket.recv(1024).decode()
    cntlist = int(data.split()[1])
    print(cntlist)
    start = len(mail)
    client_socket.sendall(b"LIST\r\n")
    receive_response(client_socket)
    for i in range(1 + start, cntlist + 1):
        retr = f"RETR {i}\r\n"
        # Receive the email content
        client_socket.sendall(retr.encode())
        _getline(client_socket)  # Discard the first line
        email = Email()
        email.num = i
        # email.attachments = []  # Assuming 'attachments' is a list to store filenames
        while True:
            line = _getline(client_socket)
            if line.startswith("From"):
                email.From = line
            if line.startswith("To:"):
                email.To = line
            if line.startswith("Cc:"):
                email.To_CC = line
            if line.startswith("Subject"):
                email.Subject = line
            if line.startswith("Content-Disposition: attachment"):
                # Extract filename from the Content-Disposition header
                email.AtName = line
                filename = line.split('; ')[1].strip()
                filename = filename.split('=')[1].strip()
                email.attachments.append(filename)
                # Save the attachment content to a file
                _getline(client_socket)
                data = _getline(client_socket)
                # Save the attachment content to a file
                save_attachment(client_socket, filename, data)
            elif line == ".":
                break
            email.Content.append(line)
        default_line = "Content-Transfer-Encoding: 7bit"
        content_started = False
        count = 0
        for line in email.Content:
            # Check if the default line is found to start extracting content
            if default_line in line:
                content_started = True
                continue

            # If content extraction has started, append lines until a blank line is encountered
            if content_started:
                if line.strip() == '':
                    count += 1
                    if count == 2:
                        break
                email.extracted_content.append(line.strip())
        mail.append(email)
    else:
        pass
    client_socket.sendall(b"QUIT\r\n")
    time.sleep(1)
    receive_response(client_socket)


def save_attachment(client_socket, filename, data):
    filename = filename.replace('"', '')
    save_path = os.path.join("", filename)
    with open(save_path, "wb") as attachment_file:
        while True:
            decoded_data = base64.b64decode(data)
            attachment_file.write(decoded_data)
            next_line = _getline(client_socket)
            if next_line == ".\r\n" or next_line == "":
                break
            else:
                data = next_line


class MailDetailsWindow:
    def __init__(self, master, email):
        email = mails[int(email.num)-1]
        self.master = master
        self.master.title(f'Mail Details - #{email.num}')
        self.master.geometry('400x400')
        self.master.resizable(False, False)
        self.master.configure(bg='#ffdce2')

        # Create a frame for displaying mail details
        self.detail_frame = tk.Frame(self.master, bg='#ffdce2', padx=10, pady=10)
        self.detail_frame.pack(fill=tk.BOTH, expand=True)

        content_text = tk.Text(self.detail_frame, wrap=tk.WORD, width=50, height=10, font=('Times', 14), borderwidth=5)
        content_text.insert(tk.END, email.From + "\n\n")
        content_text.insert(tk.END, email.To + "\n\n")
        content_text.insert(tk.END, email.To_CC + "\n\n")
        content_text.insert(tk.END, email.Subject)
        for line in email.extracted_content:
            content_text.insert(tk.END, line + "\n\n")
        content_text.insert(tk.END, email.AtName + "\n\n")
        content_text.configure(state="disabled")
        content_text.pack()

        # Add a button to open attachments and move mail to folder
        self.open_button = tk.Button(self.detail_frame, text="Open attachments",
                                     command=lambda: self.open_attachments(email),
                                     bg='#1E90FF', fg='#FFFFFF', font=('Times', 16, 'bold'))
        self.open_button.pack(side=tk.LEFT, fill=tk.X)

        self.move_button = tk.Button(self.detail_frame, text="Move",
                                     command=lambda: self.move_to_folder(email),
                                     bg='#1E90FF', fg='#FFFFFF', font=('Times', 16, 'bold'))
        self.move_button.pack(side=tk.RIGHT, fill=tk.X)

    def open_attachments(self, email):
        for attachment_path in email.attachments:
            try:
                # Open the attachment using the default associated application on Windows
                os.startfile(attachment_path)
            except Exception as e:
                print(f"Error opening attachment: {e}")
            # Add a button to move the mail to a folder

    def move_to_folder(self, email):
        # Create a new window to select the folder
        folder_selection_window = tk.Toplevel(self.master)
        folder_selection_window.title("Select Folder")
        folder_selection_window.geometry('200x160')
        folder_selection_window.configure(bg='#ffdce2')
        # Set window position
        x = (folder_selection_window.winfo_screenwidth() // 2) - (200 // 2)
        y = (folder_selection_window.winfo_screenheight() // 2) - (160 // 2)
        folder_selection_window.geometry(f'200x160+{x}+{y}')

        # Create labels and buttons for folders
        tk.Label(folder_selection_window, text="Select Folder:", bg='#ffdce2', font=('Times', 14, 'bold')).pack(pady=10)

        spam_button = tk.Button(folder_selection_window, text="Spam",
                                command=lambda: self.move_email(email, "Spam", folder_selection_window),
                                bg='#1E90FF', fg='#FFFFFF', font=('Times', 12, 'bold'))
        spam_button.pack(pady=10)

        like_button = tk.Button(folder_selection_window, text=" Like ",
                                command=lambda: self.move_email(email, "Like", folder_selection_window),
                                bg='#1E90FF', fg='#FFFFFF', font=('Times', 12, 'bold'))
        like_button.pack(pady=10)

    def move_email(self, email, folder, folder_selection_window):
        # Implement the actual logic to move the email to the selected folder
        with open(str(folder) + '.txt', 'r') as file:
            # Read the file line by line
            lines = [line.strip() for line in file.readlines()]

        with open(str(folder) + '.txt', 'a') as file:
            # Append data to the file
            if not str(email.num) in lines:
                file.write(f'{email.num}\n')
        if str(folder) == "Spam":
                    self.delete_data_from_file('Like', str(email.num))
        else:
                    self.delete_data_from_file('Spam', str(email.num))
        # You can add your logic here to move the email to the specified folder
        # Close the folder selection window after moving the email
        folder_selection_window.destroy()


    def delete_data_from_file(self, folder, data_to_delete):
        # Read the contents of the file
        with open(str(folder) + '.txt', 'r') as file:
            lines = file.readlines()

        # Modify the data (delete the specified data)
        modified_lines = [line for line in lines if data_to_delete not in line]

        # Write the modified data back to the file
        with open(str(folder) + '.txt', 'w') as file:
            file.writelines(modified_lines)


class ComposeMailApp:
    def __init__(self, master):

        # Set up window
        self.master = master
        self.master.title('Compose Mail')
        self.master.geometry('800x600')
        self.master.resizable(False, False)
        self.master.configure(bg='#ffdce2')

        # Create frame for email fields
        self.field_frame = tk.Frame(self.master, bg='#ffdce2', padx=10, pady=10)
        self.field_frame.pack(fill=tk.BOTH, expand=True)

        # Create attachment button
        self.img = tk.PhotoImage(file='attach.png')
        tk.Label(self.field_frame, image=self.img, bg='grey').place(x=650, y=460)

        # Create a button with the image
        self.settings_button = tk.Button(self.field_frame, image=self.img, bg='grey', command=self.open_settings,
                                         borderwidth=3)
        self.settings_button.place(x=650, y=455)

        # Fields for composing email
        self.from_label = tk.Label(self.field_frame, text="FROM", bg='#ffdce2', font=('Times', 16, 'bold'))
        self.from_entry = tk.Entry(self.field_frame,  width=40, font=('Times', 16), borderwidth=5)
        self.to_label = tk.Label(self.field_frame, text="TO", bg='#ffdce2', font=('Times', 16, 'bold'), borderwidth=5)
        self.to_entry = tk.Entry(self.field_frame,  width=40, font=('Times', 16), borderwidth=5)
        self.cc_label = tk.Label(self.field_frame, text="CC", bg='#ffdce2', font=('Times', 16, 'bold'), )
        self.cc_entry = tk.Entry(self.field_frame,  width=40, font=('Times', 16), borderwidth=5)
        self.bcc_label = tk.Label(self.field_frame, text="BCC", bg='#ffdce2', font=('Times', 16, 'bold'))
        self.bcc_entry = tk.Entry(self.field_frame, width=40, font=('Times', 16), borderwidth=5)
        self.subject_label = tk.Label(self.field_frame, text="SUBJECT", bg='#ffdce2', font=('Times', 16, 'bold'))
        self.subject_entry = tk.Entry(self.field_frame, width=40, font=('Times', 16), borderwidth=5)
        self.text_label = tk.Label(self.field_frame, text="TEXT", bg='#ffdce2', font=('Times', 16, 'bold'))
        self.text_entry = tk.Text(self.field_frame, wrap=tk.WORD, width=60, height=10, borderwidth=5)
        self.attachments_label = tk.Label(self.field_frame, text="ATTACHMENTS", bg='#ffdce2', font=('Times', 16, 'bold'))
        self.attachments_entry = tk.Entry(self.field_frame, width=63, font=('Times', 10), borderwidth=5)

        # Pack fields
        self.from_label.grid(row=0, column=0, sticky=tk.E)
        self.from_entry.grid(row=0, column=1, padx=10, pady=8)
        self.to_label.grid(row=1, column=0, sticky=tk.E)
        self.to_entry.grid(row=1, column=1, padx=10, pady=10)
        self.cc_label.grid(row=2, column=0, sticky=tk.E)
        self.cc_entry.grid(row=2, column=1, padx=10, pady=8)
        self.bcc_label.grid(row=3, column=0, sticky=tk.E)
        self.bcc_entry.grid(row=3, column=1, padx=10, pady=8)
        self.subject_label.grid(row=4, column=0, sticky=tk.E)
        self.subject_entry.grid(row=4, column=1, padx=10, pady=8)
        self.text_label.grid(row=5, column=0, sticky=tk.E)
        self.text_entry.grid(row=5, column=1, padx=10, pady=8)
        self.attachments_label.grid(row=6, column=0, sticky=tk.E)
        self.attachments_entry.grid(row=6, column=1, padx=10, pady=10)

        self.from_entry.insert(0, username)
        self.from_entry.config(state=tk.DISABLED)

        # Create frame for buttons
        self.button_frame = tk.Frame(self.master, bg='#ffdce2')
        self.button_frame.pack(fill=tk.BOTH, expand=True)

        # Create buttons
        self.send_button = tk.Button(self.button_frame, text="  Send  ", bg='#1E90FF', fg='#FFFFFF',
                                     font='Times 18 bold', borderwidth=10, command=self.send_mail)
        self.cancel_button = tk.Button(self.button_frame, text="Cancel", bg='#e30635', fg='#FFFFFF',
                                       font='Times 18 bold', borderwidth=10, command=self.cancel_mail)

        # Pack buttons
        self.cancel_button.pack(side=tk.LEFT, padx=10, expand=True)
        self.send_button.pack(side=tk.LEFT, padx=10, expand=True)

    def open_settings(self):
        file_paths = filedialog.askopenfilenames(title='Choose files', filetypes=[('All files', '*.*')])

        if file_paths:
            # Retrieve the current content of the attachments entry
            current_content = self.attachments_entry.get()

            # Check if current_content is not empty
            if current_content:
                # Append each chosen file path to the existing content, separated by a semicolon and a space
                new_content = f'{current_content}; {";".join(file_paths)}'
            else:
                # If current_content is empty, join the file paths directly
                new_content = ";".join(file_paths)

            # Update the attachments entry with the combined content
            self.attachments_entry.delete(0, tk.END)
            self.attachments_entry.insert(0, new_content)

    def send_mail(self):
        # Example:
        smtp_client_socket = connect_to_server(PORT1)  # Change this line
        if smtp_client_socket is None:
            return
        email = Email()
        smtp_client_socket.sendall(b"HELO\r\n")
        email.From = self.from_entry.get()
        smtp_client_socket.sendall(f"MAIL FROM:<{email.From}>\r\n".encode())

        email.To = self.to_entry.get()
        recipients = email.To.split(',')
        for recipient in recipients:
            recipient = recipient.strip()
            smtp_client_socket.sendall(f"RCPT TO:<{recipient}>\r\n".encode())

        email.To_CC = self.cc_entry.get()
        cc_recipients = email.To_CC.split(',')
        for cc_recipient in cc_recipients:
            cc_recipient = cc_recipient.strip()
            smtp_client_socket.sendall(f"RCPT TO:<{cc_recipient}>\r\n".encode())

        email.To_BCC = self.bcc_entry.get()
        bcc_recipients = email.To_BCC.split(',')
        for bcc_recipient in bcc_recipients:
            bcc_recipient = bcc_recipient.strip()
            smtp_client_socket.sendall(f"RCPT TO:<{bcc_recipient}>\r\n".encode())

        smtp_client_socket.sendall(b"DATA\r\n")
        email.From = f"From : <{self.from_entry.get()}>\r\n"
        smtp_client_socket.sendall(email.From.encode())
        recipients_str = ",".join(f"<{recipient.strip()}>" for recipient in recipients)
        smtp_client_socket.sendall(f"To: {recipients_str}\r\n".encode())

        cc_recipients_str = ",".join(f"<{cc_recipient.strip()}>" for cc_recipient in cc_recipients)
        smtp_client_socket.sendall(f"Cc: {cc_recipients_str}\r\n".encode())
        email.Subject = self.subject_entry.get()
        email.Subject = f"Subject: {email.Subject}\r\n"
        smtp_client_socket.sendall(email.Subject.encode())
        text = self.text_entry.get("1.0", tk.END)
        message = MIMEMultipart()
        text = text + "\r\n"
        # Create the message container
        message.attach(MIMEText(text, 'plain'))
        script_directory = os.path.dirname(os.path.abspath(__file__))
        attachments = self.attachments_entry.get().split(';')

        # Create the multipart container for attachments
        multipart = MIMEMultipart()
        file_size = 0
        # Create a new body part for each attachment
        if attachments:
            for attachment in attachments:
                messagebody = MIMEBase('application', 'octet-stream')
                if attachment == '':
                    pass
                else:
                    with open(attachment, 'rb') as file:
                        file_content = file.read()
                        file_size = len(file_content)
                        if file_size <= 3145728:
                            messagebody.set_payload(file_content)
                            encoders.encode_base64(messagebody)

                            # Set the filename
                            messagebody.add_header('Content-Disposition',
                                                   f'attachment; filename={os.path.basename(attachment)}; '
                                                   f'size={file_size} bytes')

                            # Add the attachment to the multipart container
                            multipart.attach(messagebody)
                        else:
                            self.master.destroy()
                            new_window = tk.Tk()
                            CheckSendSize(new_window)
                            return
            # Attach the multipart container to the main message
        message.attach(multipart)

        # Send the message
        text1 = message.as_string()
        smtp_client_socket.send(text1.encode())
        smtp_client_socket.sendall(b".\r\n")
        smtp_client_socket.sendall(b"QUIT\r\n")
        response = smtp_client_socket.recv(1024).decode()

        # Close the connection
        time.sleep(1)
        smtp_client_socket.close()

        # Close the connection
        # Add logic to send the composed mail
        # You can retrieve values from the entry widgets and perform the send operation
        if not self.from_entry.get() or (
                not self.to_entry.get() and not self.cc_entry.get() and not self.bcc_entry.get()):
            self.master.destroy()
            new_window = tk.Tk()
            CheckSendFail(new_window)
        else:
            self.master.destroy()
            new_window = tk.Tk()
            CheckSendOk(new_window)

    def cancel_mail(self):
        self.master.destroy()


class MailClientApp:
    def __init__(self, master):
        self.master = master
        self.master.title('Mail Client')
        self.master.geometry('730x630')
        self.master.resizable(False, False)
        self.master.configure(bg='#ffdce2')

        # Set window position
        x = (self.master.winfo_screenwidth() // 2) - (730 // 2)
        y = (self.master.winfo_screenheight() // 2) - (630 // 2)
        self.master.geometry(f'730x630+{x}+{y}')

        # Create frame for buttons on the left
        self.button_frame = tk.Frame(self.master, bg='#ffdce2', width=10)
        self.button_frame.pack(side=tk.LEFT, fill=tk.Y)

        # Create buttons
        self.new_button = tk.Button(self.button_frame, text=" New ", bg='#2827bd', fg='#FFFFFF', font='Times 18 bold',
                                    command=self.show_new, borderwidth=10)
        self.inbox_button = tk.Button(self.button_frame, text="Inbox", bg='#1E90FF', fg='#FFFFFF', font='Times 18 bold',
                                      command=self.show_inbox, borderwidth=10)
        self.all_button = tk.Button(self.button_frame, text="  All  ", bg='#1E90FF', fg='#FFFFFF', font='Times 18 bold',
                                     command=self.show_all, borderwidth=10)
        self.like_button = tk.Button(self.button_frame, text=" Like ", bg='#1E90FF', fg='#FFFFFF', font='Times 18 bold',
                                     command=self.show_like, borderwidth=10)
        self.spam_button = tk.Button(self.button_frame, text="Spam", bg='#1E90FF', fg='#FFFFFF', font='Times 18 bold',
                                     command=self.show_spam, borderwidth=10)
        self.trash_button = tk.Button(self.button_frame, text="Trash", bg='#1E90FF', fg='#FFFFFF', font='Times 18 bold'
                                      , command=self.show_trash, borderwidth=10)
        self.exit_button = tk.Button(self.button_frame, text=" Exit ", bg='#e30635', fg='#FFFFFF', font='Times 18 bold',
                                     command=self.show_exit, borderwidth=10)

        # Pack buttons
        self.new_button.pack(padx=15, pady=15, expand=True)
        self.inbox_button.pack(expand=True)
        self.all_button.pack(expand=True)
        self.like_button.pack(expand=True)
        self.spam_button.pack(expand=True)
        self.trash_button.pack(expand=True)
        self.exit_button.pack(expand=True)

        # Create frame for filter and table in the center
        self.center_frame = tk.Frame(self.master, bg='#ffdce2')
        self.center_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.img = tk.PhotoImage(file='filter.png')

        # Create a button filter with the image
        self.filter_button = tk.Button(self.center_frame, image=self.img, bg='grey', command=self.filter, borderwidth=3)
        self.filter_button.place(x=450, y=8)

        # Create filter entry and combobox
        self.filter_entry = tk.Entry(self.center_frame, font=('Times', 20), borderwidth=5)
        self.filter_combobox = ttk.Combobox(self.center_frame, values=['User', 'Subject', 'Content'], state='readonly',
                                            width=20)
        # Set the font for the combobox options (dropdown list)
        self.filter_combobox.set('None')
        self.filter_entry.pack(pady=10)
        self.filter_combobox.pack(pady=10)

        self.filter_entry.bind('<Return>', self.filter)

        # Create Treeview widget
        columns = ["Number", "Mail"]
        self.mail_table = ttk.Treeview(self.center_frame, columns=columns, show="headings")

        # Configure column headings
        for col in columns:
            self.mail_table.heading(col, text=col)
            self.mail_table.column(col, width=100, anchor=tk.CENTER)

        # Create a custom style for column headings
        style = ttk.Style()
        style.configure('Treeview.Heading', foreground='blue', font=('Times', 25, 'bold'))

        # Pack the Treeview widget
        self.mail_table.pack(pady=20)
        self.mail_table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.receive_mail()

        self.mail_table.bind('<ButtonRelease-1>', self.on_row_click)

        with open(SEEN_EMAILS_FILE, 'r') as file:
            # Read the file line by line
            lines = [line.strip() for line in file.readlines()]

        # Check mail seen
        for e in mails:
            for line in lines:
                if str(e.num) == line:
                    e.state = 0
            self.filter_to_spam(e, 'hihi')
        for e in mails:
            self.mail_table.insert('', 'end', values=(e.num, e.From,), tags=f'tag_{e.state}')
            if e.state == 0:
                self.mail_table.tag_configure(f'tag_{e.state}', foreground='gray', font='Times 12 bold')
            else:
                self.mail_table.tag_configure(f'tag_{e.state}', foreground='blue', font='Times 12 bold')

        self.master.after(1000, self.receive_mail_periodic)

    def on_row_click(self, event):

        # Use identify_row to get the row identifier
        item = self.mail_table.identify_row(event.y)

        # Ensure that at least one item is selected before triggering the function
        if item:
            self.handle_row_click(item)

    def open_mail_details_window(self, email):
        new_window = tk.Toplevel(self.master)
        MailDetailsWindow(new_window, email)

    def handle_row_click(self, item):

        # Retrieve the values associated with the clicked row
        values = self.mail_table.item(item, 'values')

        # Assuming that 'e' is an Email object associated with the row
        e = Email()
        e.num = values[0]
        with open(SEEN_EMAILS_FILE, 'r') as file:
            # Read the file line by line
            lines = [line.strip() for line in file.readlines()]

        with open(SEEN_EMAILS_FILE, 'a') as file:
            # Append data to the file
            if not str(e.num) in lines:
                file.write(f'{e.num}\n')
        # Call the method to open the mail details window
        self.open_mail_details_window(e)
        # Call your custom function here or perform additional actions
        # Update the text color based on the state (assuming state is an attribute of the Email object)
        self.custom_function(e)

    def custom_function(self, e):
        # Implement your custom function logic here
        e.state = 0
        self.mail_table.item(self.mail_table.selection()[0], tags=f'tag_{e.state}')

    def receive_mail(self):

        pop3_client_socket = connect_to_server(PORT2)
        if pop3_client_socket is None:
            return

        # Receive emails using POP3
        receive_emails(pop3_client_socket, mails)
        pop3_client_socket.close()

    def receive_mail_periodic(self):
        # Call the receive_mail function to update emails
        self.receive_mail()
        self.clear_table()
        with open(SEEN_EMAILS_FILE, 'r') as file:
            # Read the file line by line
            lines = [line.strip() for line in file.readlines()]

        # Check mail seen
        for e in mails:
            for line in lines:
                if str(e.num) == line:
                    e.state = 0
        for e in mails:
            self.mail_table.insert('', 'end', values=(e.num, e.From,), tags=f'tag_{e.state}')
            if e.state == 0:
                self.mail_table.tag_configure(f'tag_{e.state}', foreground='gray', font='Times 12 bold')
            else:
                self.mail_table.tag_configure(f'tag_{e.state}', foreground='blue', font='Times 12 bold')

        # Schedule the receive_mail_periodic function to be called again after 10 seconds
        self.master.after(AUTOLOAD_INTERVAL, self.receive_mail_periodic)

    def filter(self):
        self.clear_table()
        selected_field = self.filter_combobox.get()
        filter_criteria = self.filter_entry.get()
        with open(SEEN_EMAILS_FILE, 'r') as file:
            # Read the file line by line
            lines = [line.strip() for line in file.readlines()]

        # Check mail seen
        for e in mails:
            for line in lines:
                if str(e.num) == line:
                    e.state = 0
        if str(selected_field) == "User":
            for e in mails:
                if filter_criteria in e.From:
                    self.mail_table.insert('', 'end', values=(e.num, e.From,), tags=f'tag_{e.state}')
                    if e.state == 0:
                        self.mail_table.tag_configure(f'tag_{e.state}', foreground='gray', font='Times 12 bold')
                    else:
                        self.mail_table.tag_configure(f'tag_{e.state}', foreground='blue', font='Times 12 bold')
        elif str(selected_field) == "Subject":
            for e in mails:
                if str(filter_criteria) in e.Subject:
                    self.mail_table.insert('', 'end', values=(e.num, e.From,), tags=f'tag_{e.state}')
                    if e.state == 0:
                        self.mail_table.tag_configure(f'tag_{e.state}', foreground='gray', font='Times 12 bold')
                    else:
                        self.mail_table.tag_configure(f'tag_{e.state}', foreground='blue', font='Times 12 bold')
        elif str(selected_field) == "Content":
            for e in mails:
                for line in e.extracted_content:
                    if str(filter_criteria) in line:
                        self.mail_table.insert('', 'end', values=(e.num, e.From,), tags=f'tag_{e.state}')
                        if e.state == 0:
                            self.mail_table.tag_configure(f'tag_{e.state}', foreground='gray', font='Times 12 bold')
                        else:
                            self.mail_table.tag_configure(f'tag_{e.state}', foreground='blue', font='Times 12 bold')
                        break

    def show_inbox(self):
        self.clear_table()
        with open(SEEN_EMAILS_FILE, 'r') as file:
            # Read the file line by line
            lines = [line.strip() for line in file.readlines()]
        for e in mails:
            for line in lines:
                if str(e.num) == line:
                    e.state = 0
        for e in mails:
            if e.state == 1:
                self.mail_table.insert('', 'end', values=(e.num, e.From,), tags=f'tag_{e.state}')
                if e.state == 1:
                    self.mail_table.tag_configure(f'tag_{e.state}', foreground='blue', font='Times 12 bold')

    def show_new(self):
        self.open_new_window()

    def show_all(self):
        self.clear_table()

    def show_trash(self):
        self.clear_table()
        # Add logic to fetch and display Trash mails in the table

    def show_spam(self):
        self.clear_table()
        self.mail_table.bind('<ButtonRelease-1>', self.on_row_click)
        with open(SEEN_EMAILS_FILE, 'r') as file:
            # Read the file line by line
            lines = [line.strip() for line in file.readlines()]
        for e in mails:
            for line in lines:
                if str(e.num) == line:
                    e.state = 0
        with open('Spam.txt', 'r') as file:
            # Read the file line by line
            lines = [line.strip() for line in file.readlines()]
        for e in mails:
            if str(e.num) in lines:
                self.mail_table.insert('', 'end', values=(e.num, e.From,), tags=f'tag_{e.state}')
                if e.state == 0:
                    self.mail_table.tag_configure(f'tag_{e.state}', foreground='gray', font='Times 12 bold')
                else:
                    self.mail_table.tag_configure(f'tag_{e.state}', foreground='blue', font='Times 12 bold')

    def show_like(self):
        self.clear_table()
        self.mail_table.bind('<ButtonRelease-1>', self.on_row_click)
        with open(SEEN_EMAILS_FILE, 'r') as file:
            # Read the file line by line
            lines = [line.strip() for line in file.readlines()]
        for e in mails:
            for line in lines:
                if str(e.num) == line:
                    e.state = 0
        with open('Like.txt', 'r') as file:
            # Read the file line by line
            lines = [line.strip() for line in file.readlines()]
        for e in mails:
            if str(e.num) in lines:
                self.mail_table.insert('', 'end', values=(e.num, e.From,), tags=f'tag_{e.state}')
                if e.state == 0:
                    self.mail_table.tag_configure(f'tag_{e.state}', foreground='gray', font='Times 12 bold')
                else:
                    self.mail_table.tag_configure(f'tag_{e.state}', foreground='blue', font='Times 12 bold')

    def show_exit(self):
        sys.exit()

    def clear_table(self):
        # Clear existing items from the table
        for item in self.mail_table.get_children():
            self.mail_table.delete(item)

    def open_new_window(self):
        new_window = tk.Toplevel(self.master)
        ComposeMailApp(new_window)

    def filter_to_spam(self, email, data):
        if str(data) in email.From:
            with open('Spam.txt', 'r') as file:
                # Read the file line by line
                lines = [line.strip() for line in file.readlines()]

            with open('Spam.txt', 'a') as file:
                # Append data to the file
                if not str(email.num) in lines:
                    file.write(f'{email.num}\n')




class MailClientLogin:
    def __init__(self, master):

        self.master = master
        self.master.title('Mail Client')
        self.master.geometry('730x630')
        self.master.resizable(False, False)
        self.master.configure(bg='#ffdce2')

        # Set window position
        x = (self.master.winfo_screenwidth() // 2) - (730 // 2)
        y = (self.master.winfo_screenheight() // 2) - (630 // 2)
        self.master.geometry(f'730x630+{x}+{y}')

        # Creating widgets
        self.frame = tk.Frame(self.master, bg='#ffdce2')

        # Load images
        self.img = tk.PhotoImage(file='mail.png')
        self.img1 = tk.PhotoImage(file='key.png')

        # Create Labels with images
        tk.Label(self.frame, image=self.img, bg='#ffdce2').place(x=0, y=110)
        tk.Label(self.frame, image=self.img1, bg='#ffdce2').place(x=0, y=200)

        # Creating widgets
        self.login_label = tk.Label(self.frame, text='LOGIN', bg='#ffdce2', fg='#0000CD', font='Times 40 bold')
        self.username_label = tk.Label(self.frame, text=" Username", bg='#333333', fg='#FFFFFF', font='Times 20 bold')
        self.username_entry = tk.Entry(self.frame, font=("Times", 20), borderwidth=3)
        self.password_entry = tk.Entry(self.frame, show="*", font=("Times", 20), borderwidth=3)
        self.password_label = tk.Label(self.frame, text=" Password ", bg='#333333', fg='#FFFFFF', font='Times 20 bold')
        self.login_button = tk.Button(self.frame, text="Login", bg='#1E90FF', fg='#FFFFFF', font='Times 20 bold',
                                      command=self.login, borderwidth=10)
        self.output_string = tk.StringVar()
        self.output_label = tk.Label(self.master, text='', bg='#ffdce2', fg='#0000CD', font='Times 20 bold',
                                     textvariable=self.output_string)
        self.output_label.pack(pady=25)

        # Placing widgets on the screen
        self.login_label.grid(row=0, column=0, columnspan=2, sticky='news', pady=35)
        self.username_label.grid(row=1, column=0)
        self.username_entry.grid(row=1, column=1, pady=20)
        self.password_label.grid(row=2, column=0)
        self.password_entry.grid(row=2, column=1, pady=40)
        self.login_button.grid(row=3, column=0, columnspan=2, pady=30)
        self.frame.pack()

    def login(self):
        if self.username_entry.get() == username and self.password_entry.get() == password:
            self.open_new_window()
        else:
            self.output_string.set('Not right! Enter again')

    # Go to MailClientApp window
    def open_new_window(self):
        self.master.destroy()
        new_window = tk.Tk()
        MailClientApp(new_window)


class CheckSendFail:
    def __init__(self, master):
        self.master = master
        self.master.title('Fail')
        self.master.geometry('200x100')
        self.master.resizable(False, False)
        self.master.configure(bg='#ffdce2')

        # Set window position
        x = (self.master.winfo_screenwidth() // 2) - (200 // 2)
        y = (self.master.winfo_screenheight() // 2) - (100 // 2)
        self.master.geometry(f'200x100+{x}+{y}')

        # Creating widgets
        self.frame = tk.Frame(self.master, bg='#ffdce2')

        self.label = tk.Label(self.frame, text='Fail!', bg='#ffdce2', fg='#0000CD', font='Times 20 bold')

        self.fail_button = tk.Button(self.frame, text="OK", bg='#1E90FF', fg='#FFFFFF', font='Times 10 bold',
                                     command=self.fail, borderwidth=10)

        # Placing widgets on the screen
        self.label.grid(row=0, column=0, columnspan=2, sticky='news', pady=2)
        self.fail_button.grid(row=3, column=0, columnspan=2, pady=2)
        self.frame.pack()

    def fail(self):
        self.master.destroy()


class CheckSendOk:
    def __init__(self, master):
        self.master = master
        self.master.title('OK')
        self.master.geometry('200x100')
        self.master.resizable(False, False)
        self.master.configure(bg='#ffdce2')

        # Set window position
        x = (self.master.winfo_screenwidth() // 2) - (200 // 2)
        y = (self.master.winfo_screenheight() // 2) - (100 // 2)
        self.master.geometry(f'200x100+{x}+{y}')

        # Creating widgets
        self.frame = tk.Frame(self.master, bg='#ffdce2')

        self.label = tk.Label(self.frame, text='Ok!', bg='#ffdce2', fg='#0000CD', font='Times 20 bold')

        self.ok_button = tk.Button(self.frame, text="OK", bg='#1E90FF', fg='#FFFFFF', font='Times 10 bold',
                                   command=self.ok, borderwidth=10)

        # Placing widgets on the screen
        self.label.grid(row=0, column=0, columnspan=2, sticky='news', pady=2)
        self.ok_button.grid(row=3, column=0, columnspan=2, pady=2)
        self.frame.pack()

    def ok(self):
        self.master.destroy()


class CheckSendSize:
    def __init__(self, master):
        self.master = master
        self.master.title('Size over')
        self.master.geometry('200x100')
        self.master.resizable(False, False)
        self.master.configure(bg='#ffdce2')

        # Set window position
        x = (self.master.winfo_screenwidth() // 2) - (200 // 2)
        y = (self.master.winfo_screenheight() // 2) - (100 // 2)
        self.master.geometry(f'200x100+{x}+{y}')

        # Creating widgets
        self.frame = tk.Frame(self.master, bg='#ffdce2')

        self.label = tk.Label(self.frame, text='The size is over!', bg='#ffdce2', fg='#0000CD', font='Times 15 bold')

        self.ok_button = tk.Button(self.frame, text="OK", bg='#1E90FF', fg='#FFFFFF', font='Times 10 bold',
                                   command=self.ok, borderwidth=10)

        # Placing widgets on the screen
        self.label.grid(row=0, column=0, columnspan=2, sticky='news', pady=2)
        self.ok_button.grid(row=3, column=0, columnspan=2, pady=2)
        self.frame.pack()

    def ok(self):
        self.master.destroy()


if __name__ == "__main__":
    window = tk.Tk()
    app = MailClientLogin(window)
    window.mainloop()
